from models import Estudiante, CAMPOS_ESTUDIANTE
from shared.json_manager import GestorJSON
from shared.herramientas import es_email_valido


# Gestor para estudiantes
gestor = GestorJSON("data/estudiantes.json")


# TUPLAS de configuración
CAMPOS_OBLIGATORIOS = (
    "nombre",
    "apellido",
    "email",
    "carnet"
)

CAMPOS_BUSCABLES = (
    "nombre",
    "apellido",
    "email",
    "carnet"
)


# ===================== AYUDAS INTERNAS =====================

def carnets_registrados(excepto_id=None):
    """
    Devuelve un SET con los carnets registrados.
    Sirve para evitar carnets duplicados.
    """

    return {
        registro["carnet"].lower()
        for registro in gestor.leer()
        if registro["id"] != excepto_id
    }


def siguiente_id():
    registros = gestor.leer()

    ids = [
        registro["id"]
        for registro in registros
    ]

    if ids:
        return max(ids) + 1

    return 1


# ===================== CREATE =====================

def crear_estudiante(datos):
    """
    Crea un estudiante nuevo.
    Devuelve una tupla (True/False, mensaje).
    """

    try:

        # Convertimos los datos a texto
        valores = {
            campo: str(datos.get(campo, "")).strip()
            for campo in CAMPOS_ESTUDIANTE
        }

        # Revisamos campos obligatorios
        faltantes = [
            campo
            for campo in CAMPOS_OBLIGATORIOS
            if not valores[campo]
        ]

        if faltantes:
            return (
                False,
                f"Faltan campos obligatorios: "
                f"{', '.join(faltantes)}"
            )

        # Validamos email
        if not es_email_valido(valores["email"]):
            return (
                False,
                "El email no tiene un formato válido"
            )

        # Validamos carnet repetido
        if valores["carnet"].lower() in carnets_registrados():
            return (
                False,
                "Ese carnet ya está registrado"
            )

        # Creamos el objeto Estudiante
        estudiante = Estudiante(
            siguiente_id(),
            **valores
        )

        # Obtenemos los registros
        registros = gestor.leer()

        # Agregamos el nuevo estudiante
        registros.append(
            estudiante.a_diccionario()
        )

        # Guardamos
        if not gestor.guardar(registros):
            return (
                False,
                "No se pudo escribir el archivo"
            )

        return (
            True,
            f"Estudiante "
            f"{estudiante.obtener_nombre_completo()} "
            f"creado con id {estudiante.id}"
        )

    except Exception as error:
        return False, f"Error inesperado: {error}"


# ===================== READ =====================

def obtener_todos():
    """
    Devuelve una lista de objetos Estudiante.
    """

    return [
        Estudiante.desde_diccionario(registro)
        for registro in gestor.leer()
    ]


def obtener_por_id(id_estudiante):
    """
    Busca un estudiante por su ID.
    """

    for estudiante in obtener_todos():

        if estudiante.id == id_estudiante:
            return estudiante

    return None


# ===================== SEARCH =====================

def buscar_estudiantes(termino):
    """
    Busca estudiantes por nombre, apellido,
    email o carnet.
    """

    termino = termino.strip().lower()

    if not termino:
        return []

    encontrados = []

    for registro in gestor.leer():

        for campo in CAMPOS_BUSCABLES:

            if termino in str(
                registro.get(campo, "")
            ).lower():

                encontrados.append(
                    Estudiante.desde_diccionario(registro)
                )

                break

    return encontrados


# ===================== UPDATE =====================

def actualizar_estudiante(id_estudiante, cambios):
    """
    Actualiza uno o varios campos del estudiante.
    """

    try:

        # Verificamos campos desconocidos
        desconocidos = (
            set(cambios)
            - set(CAMPOS_ESTUDIANTE)
        )

        if desconocidos:
            return (
                False,
                "Campos no válidos: "
                + ", ".join(sorted(desconocidos))
            )

        if not cambios:
            return False, "No se indicó ningún cambio"

        # Validar email si se modifica
        if "email" in cambios:

            if not es_email_valido(cambios["email"]):
                return (
                    False,
                    "El email no tiene un formato válido"
                )

        # Validar carnet si se modifica
        if "carnet" in cambios:

            carnet = cambios["carnet"].lower()

            if carnet in carnets_registrados(
                excepto_id=id_estudiante
            ):
                return (
                    False,
                    "Ese carnet ya lo usa otro estudiante"
                )

        registros = gestor.leer()

        posicion = None

        # Buscamos la posición del estudiante
        for indice, registro in enumerate(registros):

            if registro["id"] == id_estudiante:
                posicion = indice
                break

        if posicion is None:
            return (
                False,
                f"No existe un estudiante "
                f"con id {id_estudiante}"
            )

        # Actualizamos el diccionario
        registros[posicion].update(cambios)

        # Guardamos
        if not gestor.guardar(registros):
            return False, "No se pudo guardar el archivo"

        return (
            True,
            f"Estudiante {id_estudiante} actualizado "
            f"({len(cambios)} campo/s)"
        )

    except Exception as error:
        return False, f"Error inesperado: {error}"


# ===================== DELETE =====================

def eliminar_estudiante(id_estudiante):
    """
    Elimina un estudiante utilizando una lista nueva.
    """

    registros = gestor.leer()

    quedan = [
        registro
        for registro in registros
        if registro["id"] != id_estudiante
    ]

    if len(quedan) == len(registros):
        return (
            False,
            f"No existe un estudiante "
            f"con id {id_estudiante}"
        )

    if not gestor.guardar(quedan):
        return False, "No se pudo guardar el archivo"

    return (
        True,
        f"Estudiante {id_estudiante} eliminado"
    )


# ===================== AGREGAR NOTA =====================

def agregar_nota(id_estudiante, materia, nota):
    """
    Agrega una nota a un estudiante.

    La nota debe estar entre 0 y 20.
    """

    try:

        # Validar nota
        if nota < 0 or nota > 20:
            return (
                False,
                "La nota debe estar entre 0 y 20"
            )

        materia = materia.strip()

        if not materia:
            return (
                False,
                "La materia no puede estar vacía"
            )

        # Buscar estudiante
        estudiante = obtener_por_id(id_estudiante)

        if estudiante is None:
            return (
                False,
                f"No existe un estudiante "
                f"con id {id_estudiante}"
            )

        # Agregar nota
        estudiante.agregar_nota(
            materia,
            nota
        )

        # Leer registros
        registros = gestor.leer()

        # Buscar registro correspondiente
        for indice, registro in enumerate(registros):

            if registro["id"] == id_estudiante:

                registros[indice] = (
                    estudiante.a_diccionario()
                )

                break

        # Guardar
        if not gestor.guardar(registros):
            return False, "No se pudo guardar la nota"

        return (
            True,
            f"Nota {nota} agregada en {materia}"
        )

    except Exception as error:
        return False, f"Error inesperado: {error}"


# ===================== PROMEDIO =====================

def obtener_promedio(id_estudiante):
    """
    Devuelve el promedio del estudiante.
    """

    estudiante = obtener_por_id(id_estudiante)

    if estudiante is None:
        return None

    return estudiante.obtener_promedio()


# ===================== MATERIAS OFERTADAS =====================

def materias_ofertadas():
    """
    Devuelve un SET con todas las materias
    inscritas por todos los estudiantes.
    """

    materias = set()

    for estudiante in obtener_todos():
        materias.update(estudiante.materias)

    return materias


# ===================== MATERIAS EN COMÚN =====================

def estudiantes_en_comun(id_a, id_b):
    """
    Devuelve las materias que comparten
    dos estudiantes.
    """

    estudiante_a = obtener_por_id(id_a)
    estudiante_b = obtener_por_id(id_b)

    if estudiante_a is None:
        return None

    if estudiante_b is None:
        return None

    return estudiante_a.materias_en_comun(
        estudiante_b
    )