from models import CAMPOS_ESTUDIANTE

from shared.herramientas import (
    imprimir_titulo,
    imprimir_exito,
    imprimir_error,
    imprimir_info,
    confirmar
)

from views import (
    crear_estudiante,
    obtener_todos,
    obtener_por_id,
    buscar_estudiantes,
    actualizar_estudiante,
    eliminar_estudiante,
    agregar_nota,
    obtener_promedio,
    materias_ofertadas,
    estudiantes_en_comun
)


def pausa():
    input("\nPresione Enter para continuar...")


# ===================== MOSTRAR TABLA =====================

def mostrar_tabla(estudiantes):

    print(
        f"{'ID':<5}"
        f"{'NOMBRE':<25}"
        f"{'EMAIL':<28}"
        f"{'CARNET':<15}"
        f"{'PROMEDIO':<10}"
    )

    print("-" * 83)

    for estudiante in estudiantes:

        print(
            f"{estudiante.id:<5}"
            f"{estudiante.obtener_nombre_completo():<25}"
            f"{estudiante.email:<28}"
            f"{estudiante.carnet:<15}"
            f"{estudiante.obtener_promedio():<10}"
        )

    print("-" * 83)

    imprimir_info(
        f"Total: {len(estudiantes)} estudiante(s)"
    )


# ===================== CREAR =====================

def opcion_crear():

    imprimir_titulo(
        "CREAR NUEVO ESTUDIANTE"
    )

    datos = {}

    for campo in CAMPOS_ESTUDIANTE:
        datos[campo] = input(
            f"{campo.capitalize()}: "
        )

    exito, mensaje = crear_estudiante(datos)

    if exito:
        imprimir_exito(mensaje)
    else:
        imprimir_error(mensaje)

    pausa()


# ===================== LEER TODOS =====================

def opcion_ver_todos():

    imprimir_titulo(
        "LISTA DE ESTUDIANTES"
    )

    estudiantes = obtener_todos()

    if not estudiantes:

        imprimir_info(
            "Todavía no hay estudiantes."
        )

    else:

        mostrar_tabla(estudiantes)

    pausa()


# ===================== BUSCAR =====================

def opcion_buscar():

    imprimir_titulo(
        "BUSCAR ESTUDIANTE"
    )

    termino = input(
        "Nombre, apellido, email o carnet: "
    )

    encontrados = buscar_estudiantes(
        termino
    )

    if not encontrados:

        imprimir_info(
            f"Ningún estudiante coincide con "
            f"'{termino}'."
        )

    else:

        mostrar_tabla(encontrados)

    pausa()


# ===================== VER POR ID =====================

def opcion_ver_por_id():

    imprimir_titulo(
        "VER ESTUDIANTE POR ID"
    )

    try:

        id_estudiante = int(
            input("Id del estudiante: ")
        )

    except ValueError:

        imprimir_error(
            "El id debe ser un número entero"
        )

        return pausa()

    estudiante = obtener_por_id(
        id_estudiante
    )

    if estudiante is None:

        imprimir_error(
            f"No existe un estudiante "
            f"con id {id_estudiante}"
        )

    else:

        print(
            f"ID: {estudiante.id}"
        )

        print(
            f"Nombre: "
            f"{estudiante.obtener_nombre_completo()}"
        )

        print(
            f"Email: {estudiante.email}"
        )

        print(
            f"Carnet: {estudiante.carnet}"
        )

        print(
            f"Promedio: "
            f"{estudiante.obtener_promedio()}"
        )

        print(
            "Materias:",
            ", ".join(
                sorted(estudiante.materias)
            )
        )

    pausa()


# ===================== EDITAR =====================

def opcion_editar():

    imprimir_titulo(
        "EDITAR ESTUDIANTE"
    )

    try:

        id_estudiante = int(
            input("Id del estudiante: ")
        )

    except ValueError:

        imprimir_error(
            "El id debe ser un número entero"
        )

        return pausa()

    estudiante = obtener_por_id(
        id_estudiante
    )

    if estudiante is None:

        imprimir_error(
            "No existe ese estudiante"
        )

        return pausa()

    print(
        "Deje vacío un campo si no desea modificarlo."
    )

    cambios = {}

    nombre = input(
        f"Nombre [{estudiante.nombre}]: "
    )

    if nombre:
        cambios["nombre"] = nombre

    apellido = input(
        f"Apellido [{estudiante.apellido}]: "
    )

    if apellido:
        cambios["apellido"] = apellido

    email = input(
        f"Email [{estudiante.email}]: "
    )

    if email:
        cambios["email"] = email

    carnet = input(
        f"Carnet [{estudiante.carnet}]: "
    )

    if carnet:
        cambios["carnet"] = carnet

    exito, mensaje = actualizar_estudiante(
        id_estudiante,
        cambios
    )

    if exito:
        imprimir_exito(mensaje)
    else:
        imprimir_error(mensaje)

    pausa()


# ===================== ELIMINAR =====================

def opcion_eliminar():

    imprimir_titulo(
        "ELIMINAR ESTUDIANTE"
    )

    try:

        id_estudiante = int(
            input("Id del estudiante: ")
        )

    except ValueError:

        imprimir_error(
            "El id debe ser un número entero"
        )

        return pausa()

    estudiante = obtener_por_id(
        id_estudiante
    )

    if estudiante is None:

        imprimir_error(
            "No existe ese estudiante"
        )

        return pausa()

    print(
        f"Estudiante: "
        f"{estudiante.obtener_nombre_completo()}"
    )

    if confirmar(
        "¿Está seguro de eliminarlo?"
    ):

        exito, mensaje = eliminar_estudiante(
            id_estudiante
        )

        if exito:
            imprimir_exito(mensaje)
        else:
            imprimir_error(mensaje)

    else:

        imprimir_info(
            "Operación cancelada."
        )

    pausa()


# ===================== AGREGAR NOTA =====================

def opcion_agregar_nota():

    imprimir_titulo(
        "AGREGAR NOTA"
    )

    try:

        id_estudiante = int(
            input("Id del estudiante: ")
        )

        nota = float(
            input("Nota (0 - 20): ")
        )

    except ValueError:

        imprimir_error(
            "El id y la nota deben ser números."
        )

        return pausa()

    materia = input(
        "Materia: "
    )

    exito, mensaje = agregar_nota(
        id_estudiante,
        materia,
        nota
    )

    if exito:
        imprimir_exito(mensaje)
    else:
        imprimir_error(mensaje)

    pausa()


# ===================== VER PROMEDIO =====================

def opcion_ver_promedio():

    imprimir_titulo(
        "VER PROMEDIO"
    )

    try:

        id_estudiante = int(
            input("Id del estudiante: ")
        )

    except ValueError:

        imprimir_error(
            "El id debe ser un número entero"
        )

        return pausa()

    estudiante = obtener_por_id(
        id_estudiante
    )

    if estudiante is None:

        imprimir_error(
            "No existe ese estudiante"
        )

    else:

        promedio = obtener_promedio(
            id_estudiante
        )

        print(
            f"Estudiante: "
            f"{estudiante.obtener_nombre_completo()}"
        )

        print(
            f"Promedio: {promedio}"
        )

        if estudiante.notas:

            print("\nNotas:")

            for materia, notas in (
                estudiante.notas.items()
            ):

                print(
                    f"- {materia}: {notas}"
                )

    pausa()


# ===================== MATERIAS OFERTADAS =====================

def opcion_materias_ofertadas():

    imprimir_titulo(
        "MATERIAS OFERTADAS"
    )

    materias = materias_ofertadas()

    if not materias:

        imprimir_info(
            "Todavía no existen materias registradas."
        )

    else:

        print("Materias:")

        for materia in sorted(materias):
            print(f"- {materia}")

    pausa()


# ===================== MATERIAS EN COMÚN =====================

def opcion_materias_comun():

    imprimir_titulo(
        "MATERIAS EN COMÚN"
    )

    try:

        id_a = int(
            input("Id del primer estudiante: ")
        )

        id_b = int(
            input("Id del segundo estudiante: ")
        )

    except ValueError:

        imprimir_error(
            "Los IDs deben ser números enteros."
        )

        return pausa()

    estudiante_a = obtener_por_id(id_a)
    estudiante_b = obtener_por_id(id_b)

    if estudiante_a is None:

        imprimir_error(
            f"No existe el estudiante {id_a}"
        )

        return pausa()

    if estudiante_b is None:

        imprimir_error(
            f"No existe el estudiante {id_b}"
        )

        return pausa()

    comunes = estudiantes_en_comun(
        id_a,
        id_b
    )

    print(
        f"{estudiante_a.obtener_nombre_completo()}"
        f" y "
        f"{estudiante_b.obtener_nombre_completo()}"
    )

    if comunes:

        print(
            "\nMaterias en común:"
        )

        for materia in sorted(comunes):
            print(f"- {materia}")

    else:

        imprimir_info(
            "No tienen materias en común."
        )

    pausa()


# ===================== MENÚ =====================

OPCIONES = {
    "1": ("Crear estudiante", opcion_crear),
    "2": ("Ver estudiantes", opcion_ver_todos),
    "3": ("Buscar estudiante", opcion_buscar),
    "4": ("Ver estudiante por ID", opcion_ver_por_id),
    "5": ("Editar estudiante", opcion_editar),
    "6": ("Eliminar estudiante", opcion_eliminar),
    "7": ("Agregar nota", opcion_agregar_nota),
    "8": ("Ver promedio", opcion_ver_promedio),
    "9": ("Materias ofertadas", opcion_materias_ofertadas),
    "10": ("Materias en común", opcion_materias_comun),
    "0": ("Salir", None)
}


def main():

    while True:

        imprimir_titulo(
            "SISTEMA DE ESTUDIANTES"
        )

        for tecla, (texto, funcion) in OPCIONES.items():

            print(
                f"{tecla}. {texto}"
            )

        print()

        opcion = input(
            "Seleccione una opción: "
        ).strip()

        if opcion == "0":

            imprimir_info(
                "Programa finalizado."
            )

            break

        if opcion not in OPCIONES:

            imprimir_error(
                "Opción no válida."
            )

            pausa()
            continue

        funcion = OPCIONES[opcion][1]

        funcion()


if __name__ == "__main__":

    try:
        main()

    except KeyboardInterrupt:

        print(
            "\nPrograma interrumpido por el usuario."
        )